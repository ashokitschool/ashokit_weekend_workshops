package com.ashok.controller;

import org.springframework.web.bind.annotation.RestController;

/**
 * This class is used to handle user requests
 * 
 * @author Ashok
 *
 */
@RestController
public class CustomerRestController {

}
